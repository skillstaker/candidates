﻿namespace test.ShippingMethods;

public partial class ExpressShippingProvider
{

    /// <summary>
    /// Express shipping provider - faster delivery at higher cost.
    /// </summary>
    public class ExpressShipping : IShippingProvider
    {
        public decimal CalculateShippingCost(double weight, double distance)
        {
            // Higher rate for express shipping (2x standard)
            decimal baseCost = (decimal)(weight * 1.0 + distance * 0.2);
            return baseCost;
        }

        public int GetEstimatedDeliveryDays() => 3;

        public string GetProviderName() => "Express Shipping";
    }

}