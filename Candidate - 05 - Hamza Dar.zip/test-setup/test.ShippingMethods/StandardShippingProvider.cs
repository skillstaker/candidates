﻿namespace test.ShippingMethods;

public partial class ExpressShippingProvider
{

    /// <summary>
    /// Standard shipping provider - economical but slower.
    /// </summary>
    public class StandardShipping : IShippingProvider
    {
        public decimal CalculateShippingCost(double weight, double distance)
        {
            // Base rate calculation for standard shipping
            decimal baseCost = (decimal)(weight * 0.5 + distance * 0.1);
            return baseCost;
        }

        public int GetEstimatedDeliveryDays() => 7;

        public string GetProviderName() => "Standard Shipping";
    }

}