﻿namespace test.ShippingMethods;

public partial class ExpressShippingProvider
{
    /// <summary>
    /// Overnight shipping provider - fastest delivery at premium cost.
    /// </summary>
    public class OvernightShipping : IShippingProvider
    {
        public decimal CalculateShippingCost(double weight, double distance)
        {
            // Premium rate for overnight shipping (3x standard)
            decimal baseCost = (decimal)(weight * 1.5 + distance * 0.3);
            decimal premiumFee = 25.0m; // Flat premium fee
            return baseCost + premiumFee;
        }

        public int GetEstimatedDeliveryDays() => 1;

        public string GetProviderName() => "Overnight Shipping";
    }
}