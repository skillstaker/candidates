﻿using test.SharedModels.Enums;

namespace test.ShippingMethods;

/// <summary>
/// Interface for shipping providers.
/// </summary>
public interface IShippingProvider
{
    /// <summary>
    /// Calculates the shipping cost based on weight and distance.
    /// </summary>
    /// <param name="weight">Weight of the package in kg</param>
    /// <param name="distance">Distance in km</param>
    /// <returns>The calculated shipping cost</returns>
    decimal CalculateShippingCost(double weight, double distance);

    /// <summary>
    /// Gets the estimated delivery time in days.
    /// </summary>
    /// <returns>Number of days for delivery</returns>
    int GetEstimatedDeliveryDays();

    /// <summary>
    /// Gets the name of the shipping provider.
    /// </summary>
    string GetProviderName();
}

/// <summary>
/// Factory class for creating shipping providers.
/// </summary>
public class ShippingFactory
{
    /// <summary>
    /// Creates a shipping provider based on the specified shipping type.
    /// </summary>
    /// <param name="shippingType">The type of shipping provider to create</param>
    /// <returns>An instance of the appropriate shipping provider</returns>
    /// <exception cref="ArgumentException">Thrown when an unsupported shipping type is provided</exception>
    /// Explicitly works off of an Enum for type consistency
    public static IShippingProvider CreateShippingProvider(ShippingType shippingType)
    {
        return shippingType switch
        {
            ShippingType.Standard => new ExpressShippingProvider.StandardShipping(),
            ShippingType.Express => new ExpressShippingProvider.ExpressShipping(),
            ShippingType.Overnight => new ExpressShippingProvider.OvernightShipping(),
            _ => throw new ArgumentException($"Unsupported shipping type: {shippingType}", nameof(shippingType))
        };
    }

    /// <summary>
    /// Gets information about all available shipping options for a given package.
    /// </summary>
    /// <param name="weight">Weight of the package in kg</param>
    /// <param name="distance">Distance in km</param>
    /// <returns>A collection of shipping options with cost and delivery time</returns>
    public static IEnumerable<ShippingOptions> GetAllShippingOptions(double weight, double distance)
    {
        foreach (ShippingType type in Enum.GetValues(typeof(ShippingType)))
        {
            var provider = CreateShippingProvider(type);
            yield return new ShippingOptions
            {
                Type = type,
                ProviderName = provider.GetProviderName(),
                Cost = provider.CalculateShippingCost(weight, distance),
                EstimatedDeliveryDays = provider.GetEstimatedDeliveryDays()
            };
        }
    }
}