﻿namespace test.Repository;

/// <summary>
/// Base interface for entities that can be stored in a repository.
/// </summary>
public interface IEntity
{
    /// <summary>
    /// Gets or sets the unique identifier for this entity.
    /// </summary>
    int Id { get; set; }
}

/// <summary>
/// Generic repository interface defining common data access operations.
/// </summary>
/// <typeparam name="T">The entity type, which must implement IEntity</typeparam>
public interface IRepository<T> where T : IEntity
{
    /// <summary>
    /// Retrieves an entity by its unique identifier.
    /// </summary>
    /// <param name="id">The entity identifier</param>
    /// <returns>The entity if found, null otherwise</returns>
    T? GetById(int id);

    /// <summary>
    /// Retrieves all entities from the repository.
    /// </summary>
    /// <returns>A collection of all entities</returns>
    IEnumerable<T> GetAll();

    /// <summary>
    /// Adds a new entity to the repository.
    /// </summary>
    /// <param name="entity">The entity to add</param>
    void Add(T entity);

    /// <summary>
    /// Updates an existing entity in the repository.
    /// </summary>
    /// <param name="entity">The entity to update</param>
    void Update(T entity);

    /// <summary>
    /// Deletes an entity by its unique identifier.
    /// </summary>
    /// <param name="id">The identifier of the entity to delete</param>
    /// <returns>True if the entity was deleted, false otherwise</returns>
    bool Delete(int id);

    /// <summary>
    /// Checks if an entity with the specified identifier exists.
    /// </summary>
    /// <param name="id">The entity identifier</param>
    /// <returns>True if the entity exists, false otherwise</returns>
    bool Exists(int id);
}
