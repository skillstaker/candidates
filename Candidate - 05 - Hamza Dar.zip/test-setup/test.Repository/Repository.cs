﻿namespace test.Repository;

/// <summary>
/// In-memory implementation of the repository pattern.
/// </summary>
/// <typeparam name="T">The entity type</typeparam>
public class Repository<T> : IRepository<T> where T : IEntity
{
    // In-memory storage using a dictionary
    private readonly Dictionary<int, T> _storage = new();
    private int _nextId = 1;

    public T? GetById(int id)
    {
        return _storage.TryGetValue(id, out var entity) ? entity : default;
    }

    public IEnumerable<T> GetAll()
    {
        return _storage.Values.ToList();
    }

    public void Add(T entity)
    {
        if (entity == null)
        {
            throw new ArgumentNullException(nameof(entity), "Entity cannot be null");
        }

        // Auto-assign ID if not set
        if (entity.Id == 0)
        {
            entity.Id = _nextId++;
        }
        else
        {
            // Ensure the next ID is always greater than any manually set ID
            if (entity.Id >= _nextId)
            {
                _nextId = entity.Id + 1;
            }
        }

        if (_storage.ContainsKey(entity.Id))
        {
            throw new InvalidOperationException($"An entity with ID {entity.Id} already exists");
        }

        _storage[entity.Id] = entity;
    }

    public void Update(T entity)
    {
        if (entity == null)
        {
            throw new ArgumentNullException(nameof(entity), "Entity cannot be null");
        }

        if (!_storage.ContainsKey(entity.Id))
        {
            throw new InvalidOperationException($"Entity with ID {entity.Id} not found");
        }

        _storage[entity.Id] = entity;
    }

    public bool Delete(int id)
    {
        return _storage.Remove(id);
    }

    public bool Exists(int id)
    {
        return _storage.ContainsKey(id);
    }

    /// <summary>
    /// Gets the total count of entities in the repository.
    /// </summary>
    public int Count => _storage.Count;

    /// <summary>
    /// Clears all entities from the repository.
    /// </summary>
    public void Clear()
    {
        _storage.Clear();
        _nextId = 1;
    }
}