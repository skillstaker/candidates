﻿namespace test.PaymentMethods;

/// <summary>
/// Concrete strategy for PayPal payments.
/// </summary>
public class PaypalPaymentMethod : IPaymentMethods
{
    private readonly string _email;

    public PaypalPaymentMethod(string email)
    {
        _email = email;
    }

    public bool ProcessPayment(decimal amount)
    {
        // Simulate PayPal processing logic
        Console.WriteLine($"Processing PayPal payment of ${amount}");
        Console.WriteLine($"PayPal account: {_email}");
        return true;
    }

    public string GetPaymentMethodName() => "PayPal";
}
