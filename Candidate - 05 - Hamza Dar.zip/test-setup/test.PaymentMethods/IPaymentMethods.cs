﻿namespace test.PaymentMethods;

/// <summary>
/// Strategy interface defining the payment processing contract.
/// This interface enables different payment methods to be used interchangeably
/// </summary>
public interface IPaymentMethods
{
    /// <summary>
    /// Processes a payment for the specified amount.
    /// </summary>
    /// <param name="amount">The amount to be processed</param>
    /// <returns>True if payment was successful, false otherwise</returns>
    bool ProcessPayment(decimal amount);

    /// <summary>
    /// Gets the name of the payment method.
    /// </summary>
    string GetPaymentMethodName();
}

