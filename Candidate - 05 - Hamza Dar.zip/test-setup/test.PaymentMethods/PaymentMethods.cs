﻿namespace test.PaymentMethods;

/// <summary>
/// Context class that uses a payment strategy.
/// This class demonstrates the Strategy Pattern by allowing runtime selection of payment methods.
/// Uses direct "method" type instead of enums
/// </summary>
public class PaymentContext
{
    private IPaymentMethods? _paymentStrategy;

    /// <summary>
    /// Sets the payment strategy to be used for processing.
    /// </summary>
    /// <param name="methods">The payment strategy to use</param>
    public void SetPaymentStrategy(IPaymentMethods methods)
    {
        _paymentStrategy = methods;
    }

    /// <summary>
    /// Executes the payment using the current strategy.
    /// </summary>
    /// <param name="amount">The amount to process</param>
    /// <returns>True if payment was successful</returns>
    /// <exception cref="InvalidOperationException">Thrown when no payment strategy is set</exception>
    public bool ExecutePayment(decimal amount)
    {
        if (_paymentStrategy == null)
        {
            throw new InvalidOperationException("Payment strategy not set. Please set a payment strategy before executing payment.");
        }

        Console.WriteLine($"\n--- Processing payment via {_paymentStrategy.GetPaymentMethodName()} ---");
        return _paymentStrategy.ProcessPayment(amount);
    }
}