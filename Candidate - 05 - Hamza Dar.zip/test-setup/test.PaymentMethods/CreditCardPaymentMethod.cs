﻿namespace test.PaymentMethods;

/// <summary>
/// Concrete strategy for credit card payments.
/// </summary>
public class CreditCardPaymentMethod : IPaymentMethods
{
    private readonly string _cardNumber;
    private readonly string _cvv;

    public CreditCardPaymentMethod(string cardNumber, string cvv)
    {
        _cardNumber = cardNumber;
        _cvv = cvv;
    }

    public bool ProcessPayment(decimal amount)
    {
        // Simulate credit card processing logic
        Console.WriteLine($"Processing credit card payment of ${amount}");
        Console.WriteLine($"Card ending in: {_cardNumber[^4..]}");
        return true;
    }
    
    public string GetPaymentMethodName() => "Credit Card";
}
