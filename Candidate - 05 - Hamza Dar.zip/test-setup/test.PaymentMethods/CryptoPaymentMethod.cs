﻿namespace test.PaymentMethods;

/// <summary>
/// Concrete strategy for cryptocurrency payments.
/// </summary>
public class CryptoPaymentMethod : IPaymentMethods
{
    private readonly string _walletAddress;
    private readonly string _cryptoType;

    public CryptoPaymentMethod(string walletAddress, string cryptoType = "BTC")
    {
        _walletAddress = walletAddress;
        _cryptoType = cryptoType;
    }

    public bool ProcessPayment(decimal amount)
    {
        // Simulate cryptocurrency processing logic
        Console.WriteLine($"Processing {_cryptoType} payment of ${amount}");
        Console.WriteLine($"Wallet: {_walletAddress}");
        return true;
    }

    public string GetPaymentMethodName() => $"Cryptocurrency ({_cryptoType})";
}