﻿namespace test.SharedModels.Enums;

/// <summary>
/// Enum representing the status of an order.
/// </summary>
public enum OrderStatus
{
    Pending,
    Processing,
    Shipped,
    Delivered,
    Cancelled
}