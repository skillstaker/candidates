﻿namespace test.SharedModels.Enums;


/// <summary>
/// Enum defining available shipping types.
/// </summary>
public enum ShippingType
{
    Standard,
    Express,
    Overnight
}