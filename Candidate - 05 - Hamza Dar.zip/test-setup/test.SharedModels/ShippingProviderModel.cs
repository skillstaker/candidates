﻿using test.SharedModels.Enums;

namespace test.ShippingMethods;

/// <summary>
/// Data transfer object representing a shipping option.
/// Ideally it should be in a DTO project but for a small sized setup like this, I've decided to merge it with shared models
/// </summary>
public class ShippingOptions
{
    public ShippingType Type { get; set; }
    public string ProviderName { get; set; } = string.Empty;
    public decimal Cost { get; set; }
    public int EstimatedDeliveryDays { get; set; }

    public override string ToString()
    {
        return $"{ProviderName}: ${Cost:F2} - {EstimatedDeliveryDays} days";
    }
}
