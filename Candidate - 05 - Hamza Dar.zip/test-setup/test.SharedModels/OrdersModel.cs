﻿using test.SharedModels.Enums;

namespace test.SharedModels;

/// <summary>
/// Represents an order in the system.
/// </summary>
public class OrdersModel
{
    public int OrderId { get; set; }
    public decimal Amount { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public DateTime OrderDate { get; set; }
    public OrderStatus Status { get; set; }

    public override string ToString()
    {
        return $"Order #{OrderId}: {CustomerName} - ${Amount:F2} [{Status}]";
    }
}
