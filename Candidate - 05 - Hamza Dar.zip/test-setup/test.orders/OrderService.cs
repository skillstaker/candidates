﻿using test.SharedModels;
using test.SharedModels.Enums;

namespace test.orders;

/// <summary>
/// Core order service implementation.
/// </summary>
public class OrderService : IOrderService
{
    private readonly Dictionary<int, OrdersModel> _orders = new();

    public bool PlaceOrder(OrdersModel order)
    {
        if (order == null)
        {
            return false;
        }

        order.OrderDate = DateTime.Now;
        order.Status = OrderStatus.Pending;
        _orders[order.OrderId] = order;
        return true;
    }

    public bool CancelOrder(int orderId)
    {
        if (_orders.TryGetValue(orderId, out var order))
        {
            order.Status = OrderStatus.Cancelled;
            return true;
        }
        return false;
    }

    public OrdersModel? GetOrder(int orderId)
    {
        return _orders.TryGetValue(orderId, out var order) ? order : null;
    }
}

/// <summary>
/// Abstract base decorator for order service.
/// </summary>
public abstract class OrderServiceDecorator : IOrderService
{
    protected readonly IOrderService _decoratedService;

    protected OrderServiceDecorator(IOrderService service)
    {
        _decoratedService = service ?? throw new ArgumentNullException(nameof(service));
    }

    public virtual bool PlaceOrder(OrdersModel order)
    {
        return _decoratedService.PlaceOrder(order);
    }

    public virtual bool CancelOrder(int orderId)
    {
        return _decoratedService.CancelOrder(orderId);
    }

    public virtual OrdersModel? GetOrder(int orderId)
    {
        return _decoratedService.GetOrder(orderId);
    }
}

/// <summary>
/// Validation decorator that adds validation logic to order service.
/// </summary>
public class ValidationOrderServiceDecorator : OrderServiceDecorator
{
    public ValidationOrderServiceDecorator(IOrderService service) : base(service)
    {
    }

    public override bool PlaceOrder(OrdersModel order)
    {
        // Validation logic
        if (order == null)
        {
            Console.WriteLine("[VALIDATION] Order cannot be null");
            return false;
        }

        if (string.IsNullOrWhiteSpace(order.CustomerName))
        {
            Console.WriteLine("[VALIDATION] Customer name is required");
            return false;
        }

        if (order.Amount <= 0)
        {
            Console.WriteLine("[VALIDATION] Order amount must be greater than zero");
            return false;
        }

        Console.WriteLine("[VALIDATION] Order validation passed");
        return base.PlaceOrder(order);
    }

    public override bool CancelOrder(int orderId)
    {
        if (orderId <= 0)
        {
            Console.WriteLine("[VALIDATION] Invalid order ID");
            return false;
        }

        Console.WriteLine("[VALIDATION] Order ID validation passed");
        return base.CancelOrder(orderId);
    }
}