﻿using test.SharedModels;

namespace test.orders;

/// <summary>
/// Interface for order processing service.
/// </summary>
public interface IOrderService
{
    /// <summary>
    /// Places a new order.
    /// </summary>
    /// <param name="order">The order to place</param>
    /// <returns>True if the order was successfully placed</returns>
    bool PlaceOrder(OrdersModel order);

    /// <summary>
    /// Cancels an existing order.
    /// </summary>
    /// <param name="orderId">The ID of the order to cancel</param>
    /// <returns>True if the order was successfully cancelled</returns>
    bool CancelOrder(int orderId);

    /// <summary>
    /// Gets an order by its ID.
    /// </summary>
    /// <param name="orderId">The order ID</param>
    /// <returns>The order if found, null otherwise</returns>
    OrdersModel? GetOrder(int orderId);
}