using test.PaymentMethods;
using test.Repository;
using test.Repository.RepositoryModels;
using test.SharedModels;
using test.SharedModels.Enums;
using test.ShippingMethods;
using test.orders;

//annotations and comments throughout the code are self-added, they are just made prettier by using claude at the end.
// demo driver program to make sure things are working as designed for different sections and modules created by claude
namespace test.DriverProgram;

/// <summary>
/// Driver program to demonstrate and test all design patterns implemented in the solution.
/// This program tests:
/// 1. Factory Pattern (ShippingFactory)
/// 2. Strategy Pattern (Payment methods)
/// 3. Repository Pattern (Generic repository)
/// 4. Decorator Pattern (OrderService decorators)
/// </summary>
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("=".PadRight(80, '='));
        Console.WriteLine("COMPREHENSIVE DESIGN PATTERNS DRIVER PROGRAM");
        Console.WriteLine("=".PadRight(80, '='));
        Console.WriteLine();

        // Run all test scenarios
        TestFactoryPattern();
        TestStrategyPattern();
        TestRepositoryPattern();
        TestDecoratorPattern();
        TestIntegratedScenario();

        Console.WriteLine();
        Console.WriteLine("=".PadRight(80, '='));
        Console.WriteLine("ALL TESTS COMPLETED SUCCESSFULLY!");
        Console.WriteLine("=".PadRight(80, '='));
    }

    /// <summary>
    /// Tests the Factory Pattern implementation with ShippingFactory.
    /// Demonstrates creating different shipping providers using the factory.
    /// </summary>
    static void TestFactoryPattern()
    {
        PrintSectionHeader("1. FACTORY PATTERN - Shipping Provider Creation");

        // Test creating each type of shipping provider
        var shippingTypes = new[] { ShippingType.Standard, ShippingType.Express, ShippingType.Overnight };
        double testWeight = 5.5; // kg
        double testDistance = 150.0; // km

        Console.WriteLine($"Package Details: Weight = {testWeight}kg, Distance = {testDistance}km");
        Console.WriteLine();

        foreach (var shippingType in shippingTypes)
        {
            // Create shipping provider using factory
            var shippingProvider = ShippingFactory.CreateShippingProvider(shippingType);

            // Calculate cost and display results
            decimal calculatedCost = shippingProvider.CalculateShippingCost(testWeight, testDistance);
            int estimatedDays = shippingProvider.GetEstimatedDeliveryDays();

            Console.WriteLine($"[{shippingProvider.GetProviderName()}]");
            Console.WriteLine($"  - Cost: ${calculatedCost:F2}");
            Console.WriteLine($"  - Delivery: {estimatedDays} days");
            Console.WriteLine();
        }

        // Test GetAllShippingOptions method
        Console.WriteLine("--- Comparing All Shipping Options ---");
        var allOptions = ShippingFactory.GetAllShippingOptions(testWeight, testDistance);
        foreach (var option in allOptions)
        {
            Console.WriteLine($"  {option}");
        }

        // Test invalid shipping type handling
        Console.WriteLine();
        Console.WriteLine("--- Testing Error Handling ---");
        try
        {
            var invalidProvider = ShippingFactory.CreateShippingProvider((ShippingType)999);
            Console.WriteLine("ERROR: Should have thrown exception for invalid type!");
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"✓ Correctly caught exception: {ex.Message}");
        }

        Console.WriteLine();
    }

    /// <summary>
    /// Tests the Strategy Pattern implementation with different payment methods.
    /// Demonstrates runtime selection of payment strategies.
    /// </summary>
    static void TestStrategyPattern()
    {
        PrintSectionHeader("2. STRATEGY PATTERN - Payment Method Selection");

        decimal paymentAmount = 299.99m;
        var paymentContext = new PaymentContext();

        // Test Credit Card payment
        Console.WriteLine("Scenario 1: Customer pays with Credit Card");
        var creditCardPayment = new CreditCardPaymentMethod("4532-1234-5678-9010", "123");
        paymentContext.SetPaymentStrategy(creditCardPayment);
        bool creditCardResult = paymentContext.ExecutePayment(paymentAmount);
        Console.WriteLine($"Payment Result: {(creditCardResult ? "SUCCESS" : "FAILED")}");
        Console.WriteLine();

        // Test PayPal payment
        Console.WriteLine("Scenario 2: Customer pays with PayPal");
        var paypalPayment = new PaypalPaymentMethod("customer@example.com");
        paymentContext.SetPaymentStrategy(paypalPayment);
        bool paypalResult = paymentContext.ExecutePayment(paymentAmount);
        Console.WriteLine($"Payment Result: {(paypalResult ? "SUCCESS" : "FAILED")}");
        Console.WriteLine();

        // Test Cryptocurrency payment
        Console.WriteLine("Scenario 3: Customer pays with Cryptocurrency");
        var cryptoPayment = new CryptoPaymentMethod("1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa", "ETH");
        paymentContext.SetPaymentStrategy(cryptoPayment);
        bool cryptoResult = paymentContext.ExecutePayment(paymentAmount);
        Console.WriteLine($"Payment Result: {(cryptoResult ? "SUCCESS" : "FAILED")}");
        Console.WriteLine();

        // Test error handling - no strategy set
        Console.WriteLine("--- Testing Error Handling ---");
        var emptyContext = new PaymentContext();
        try
        {
            emptyContext.ExecutePayment(100m);
            Console.WriteLine("ERROR: Should have thrown exception!");
        }
        catch (InvalidOperationException ex)
        {
            Console.WriteLine($"✓ Correctly caught exception: {ex.Message}");
        }

        Console.WriteLine();
    }

    /// <summary>
    /// Tests the Repository Pattern implementation with generic repository.
    /// Demonstrates CRUD operations with different entity types.
    /// </summary>
    static void TestRepositoryPattern()
    {
        PrintSectionHeader("3. REPOSITORY PATTERN - Data Access Operations");

        // Test with Customer entities
        Console.WriteLine("--- Testing Customer Repository ---");
        var customerRepository = new Repository<Customer>();

        // Create and add customers
        var customer1 = new Customer
        {
            Name = "John Doe",
            Email = "john.doe@example.com",
            RegistrationDate = DateTime.Now
        };
        customerRepository.Add(customer1);
        Console.WriteLine($"✓ Added: {customer1}");

        var customer2 = new Customer
        {
            Name = "Jane Smith",
            Email = "jane.smith@example.com",
            RegistrationDate = DateTime.Now
        };
        customerRepository.Add(customer2);
        Console.WriteLine($"✓ Added: {customer2}");

        // Test retrieval
        var retrievedCustomer = customerRepository.GetById(1);
        Console.WriteLine($"✓ Retrieved by ID: {retrievedCustomer}");

        // Test update
        if (retrievedCustomer != null)
        {
            retrievedCustomer.Email = "john.updated@example.com";
            customerRepository.Update(retrievedCustomer);
            Console.WriteLine($"✓ Updated: {customerRepository.GetById(1)}");
        }

        // Test GetAll
        Console.WriteLine($"✓ Total customers: {customerRepository.Count}");
        foreach (var customer in customerRepository.GetAll())
        {
            Console.WriteLine($"  - {customer}");
        }

        Console.WriteLine();

        // Test with Product entities
        Console.WriteLine("--- Testing Product Repository ---");
        var productRepository = new Repository<Product>();

        var product1 = new Product
        {
            Name = "Laptop",
            Price = 1299.99m,
            StockQuantity = 50
        };
        productRepository.Add(product1);
        Console.WriteLine($"✓ Added: {product1}");

        var product2 = new Product
        {
            Name = "Wireless Mouse",
            Price = 29.99m,
            StockQuantity = 200
        };
        productRepository.Add(product2);
        Console.WriteLine($"✓ Added: {product2}");

        // Test delete
        bool deleteResult = productRepository.Delete(2);
        Console.WriteLine($"✓ Deleted product ID 2: {(deleteResult ? "SUCCESS" : "FAILED")}");
        Console.WriteLine($"✓ Remaining products: {productRepository.Count}");

        // Test exists
        bool existsCheck = productRepository.Exists(1);
        Console.WriteLine($"✓ Product ID 1 exists: {existsCheck}");

        Console.WriteLine();
    }

    /// <summary>
    /// Tests the Decorator Pattern implementation with OrderService decorators.
    /// Demonstrates adding cross-cutting concerns (validation) via decorators.
    /// </summary>
    static void TestDecoratorPattern()
    {
        PrintSectionHeader("4. DECORATOR PATTERN - Order Service with Validation");

        // Test basic OrderService without decorators
        Console.WriteLine("--- Scenario 1: Basic OrderService (No Validation) ---");
        IOrderService basicOrderService = new OrderService();

        var validOrder = new OrdersModel
        {
            OrderId = 1,
            CustomerName = "Alice Johnson",
            Amount = 150.75m
        };

        bool basicPlaceResult = basicOrderService.PlaceOrder(validOrder);
        Console.WriteLine($"Order placed: {(basicPlaceResult ? "SUCCESS" : "FAILED")}");

        var retrievedOrder = basicOrderService.GetOrder(1);
        Console.WriteLine($"Retrieved: {retrievedOrder}");
        Console.WriteLine();

        // Test OrderService with ValidationDecorator
        Console.WriteLine("--- Scenario 2: OrderService with Validation Decorator ---");
        IOrderService validatedOrderService = new ValidationOrderServiceDecorator(new OrderService());

        // Test valid order
        Console.WriteLine("\nTest Case: Valid Order");
        var validOrder2 = new OrdersModel
        {
            OrderId = 2,
            CustomerName = "Bob Williams",
            Amount = 250.00m
        };
        bool validOrderResult = validatedOrderService.PlaceOrder(validOrder2);
        Console.WriteLine($"Result: {(validOrderResult ? "SUCCESS" : "FAILED")}");

        // Test invalid order - null customer name
        Console.WriteLine("\nTest Case: Invalid Order (Empty Customer Name)");
        var invalidOrder1 = new OrdersModel
        {
            OrderId = 3,
            CustomerName = "",
            Amount = 100.00m
        };
        bool invalidOrderResult1 = validatedOrderService.PlaceOrder(invalidOrder1);
        Console.WriteLine($"Result: {(invalidOrderResult1 ? "SUCCESS" : "FAILED")}");

        // Test invalid order - negative amount
        Console.WriteLine("\nTest Case: Invalid Order (Negative Amount)");
        var invalidOrder2 = new OrdersModel
        {
            OrderId = 4,
            CustomerName = "Charlie Brown",
            Amount = -50.00m
        };
        bool invalidOrderResult2 = validatedOrderService.PlaceOrder(invalidOrder2);
        Console.WriteLine($"Result: {(invalidOrderResult2 ? "SUCCESS" : "FAILED")}");

        // Test cancel order validation
        Console.WriteLine("\nTest Case: Cancel Order with Invalid ID");
        bool cancelResult = validatedOrderService.CancelOrder(-1);
        Console.WriteLine($"Result: {(cancelResult ? "SUCCESS" : "FAILED")}");

        Console.WriteLine();
    }

    /// <summary>
    /// Tests an integrated scenario combining multiple patterns.
    /// Simulates a complete e-commerce order flow using all patterns together.
    /// </summary>
    static void TestIntegratedScenario()
    {
        PrintSectionHeader("5. INTEGRATED SCENARIO - Complete E-Commerce Flow");

        Console.WriteLine("Simulating a complete customer order process...");
        Console.WriteLine();

        // Step 1: Create customer using Repository Pattern
        Console.WriteLine("STEP 1: Customer Registration");
        var customerRepo = new Repository<Customer>();
        var newCustomer = new Customer
        {
            Name = "David Martinez",
            Email = "david.martinez@example.com",
            RegistrationDate = DateTime.Now
        };
        customerRepo.Add(newCustomer);
        Console.WriteLine($"  ✓ Customer registered: {newCustomer}");
        Console.WriteLine();

        // Step 2: Browse products using Repository Pattern
        Console.WriteLine("STEP 2: Product Selection");
        var productRepo = new Repository<Product>();
        var selectedProduct = new Product
        {
            Name = "Smartphone",
            Price = 799.99m,
            StockQuantity = 100
        };
        productRepo.Add(selectedProduct);
        Console.WriteLine($"  ✓ Product selected: {selectedProduct}");
        Console.WriteLine();

        // Step 3: Calculate shipping using Factory Pattern
        Console.WriteLine("STEP 3: Shipping Calculation");
        double packageWeight = 0.5; // kg
        double shippingDistance = 250.0; // km

        Console.WriteLine($"  Package: {packageWeight}kg, Distance: {shippingDistance}km");
        Console.WriteLine("  Available shipping options:");

        var shippingOptions = ShippingFactory.GetAllShippingOptions(packageWeight, shippingDistance);
        ShippingOptions? selectedShipping = null;

        foreach (var option in shippingOptions)
        {
            Console.WriteLine($"    - {option}");
            // Select Express shipping for this scenario
            if (option.Type == ShippingType.Express)
            {
                selectedShipping = option;
            }
        }

        Console.WriteLine($"  ✓ Selected: {selectedShipping}");
        Console.WriteLine();

        // Step 4: Process payment using Strategy Pattern
        Console.WriteLine("STEP 4: Payment Processing");
        decimal totalAmount = selectedProduct.Price + (selectedShipping?.Cost ?? 0);
        Console.WriteLine($"  Total Amount: ${totalAmount:F2}");

        var paymentContext = new PaymentContext();
        var paymentMethod = new CreditCardPaymentMethod("4532-9876-5432-1098", "456");
        paymentContext.SetPaymentStrategy(paymentMethod);

        bool paymentSuccess = paymentContext.ExecutePayment(totalAmount);
        Console.WriteLine($"  Payment Status: {(paymentSuccess ? "SUCCESS" : "FAILED")}");
        Console.WriteLine();

        // Step 5: Place order using Decorator Pattern
        Console.WriteLine("STEP 5: Order Placement");
        IOrderService orderService = new ValidationOrderServiceDecorator(new OrderService());

        var finalOrder = new OrdersModel
        {
            OrderId = 1001,
            CustomerName = newCustomer.Name,
            Amount = totalAmount
        };

        bool orderPlaced = orderService.PlaceOrder(finalOrder);

        if (orderPlaced)
        {
            var placedOrder = orderService.GetOrder(1001);
            Console.WriteLine($"  ✓ Order confirmed: {placedOrder}");
            Console.WriteLine($"  ✓ Status: {placedOrder?.Status}");
            Console.WriteLine($"  ✓ Order Date: {placedOrder?.OrderDate}");
        }
        else
        {
            Console.WriteLine("  ✗ Order placement failed!");
        }

        Console.WriteLine();
        Console.WriteLine("--- Order Summary ---");
        Console.WriteLine($"Customer: {newCustomer.Name} ({newCustomer.Email})");
        Console.WriteLine($"Product: {selectedProduct.Name} - ${selectedProduct.Price:F2}");
        Console.WriteLine($"Shipping: {selectedShipping?.ProviderName} - ${selectedShipping?.Cost:F2}");
        Console.WriteLine($"Total: ${totalAmount:F2}");
        Console.WriteLine($"Payment: {paymentMethod.GetPaymentMethodName()}");
        Console.WriteLine($"Order Status: {(orderPlaced ? "CONFIRMED" : "FAILED")}");

        Console.WriteLine();
    }

    /// <summary>
    /// Helper method to print formatted section headers.
    /// </summary>
    /// <param name="headerText">The header text to display</param>
    static void PrintSectionHeader(string headerText)
    {
        Console.WriteLine();
        Console.WriteLine("-".PadRight(80, '-'));
        Console.WriteLine(headerText);
        Console.WriteLine("-".PadRight(80, '-'));
        Console.WriteLine();
    }
}
