﻿namespace OrderProblem.Repository
{
    public class OrderRepositery<T> : IRepository<T> where T : class
    {
        public Task<T1> AddAsync<T1>(T1 Entity)
        {

           return Task.FromResult(Entity);
        }

        public Task<T1> DeleteAsync<T1>(int id)
        {
            throw new NotImplementedException();
        }

        public Task<T1> GetTAsync<T1>(int id)
        {
            throw new NotImplementedException();
        }

        public Task<T1> UpdateAsync<T1>(int id, T1 Entity)
        {
            throw new NotImplementedException();
        }
    }
}
