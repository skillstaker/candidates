﻿namespace OrderProblem.Repository
{
    public interface IRepository<in T> where T : class
    {
        Task<T> GetTAsync<T>(int id);
        Task<T> AddAsync<T>(T Entity);
        Task<T> UpdateAsync<T>(int id, T Entity);
        Task<T> DeleteAsync<T>(int id);
    }
}
