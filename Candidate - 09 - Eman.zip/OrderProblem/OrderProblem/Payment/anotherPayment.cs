﻿using OrderProblem.Models;

namespace OrderProblem.Payment
{
    public class anotherPayment : IPaymentStrategy
    {
        public Task<PaymentResult> pay(order order, int PaymentType)
        {
            throw new NotImplementedException();
        }
    }
}
