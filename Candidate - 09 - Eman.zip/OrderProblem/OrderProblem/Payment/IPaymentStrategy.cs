﻿using OrderProblem.Models;

namespace OrderProblem.Payment
{
    public record PaymentResult();
    public interface IPaymentStrategy
    {
        Task<PaymentResult> pay(order order,int PaymentType);
    }
}
