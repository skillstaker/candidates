﻿using OrderProblem.Models;

namespace OrderProblem.Payment
{
    public class CreidtCardPayment : IPaymentStrategy
    {
        public Task<PaymentResult> pay(order order, int PaymentType)
        {
            throw new NotImplementedException();
        }
    }
}
