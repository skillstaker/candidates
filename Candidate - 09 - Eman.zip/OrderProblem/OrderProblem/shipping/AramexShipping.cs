﻿using OrderProblem.Models;

namespace OrderProblem.shipping
{
    public class AramexShipping : IShipping
    {
        public Task ShipAsync(order order)
        {
            throw new NotImplementedException();
        }
    }
}
