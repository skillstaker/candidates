﻿namespace OrderProblem.shipping
{
    public static class ShippingFactory
    {
        public static IShipping Create(string provider)
        {
            switch (provider)
            {
                case "aramex":
                    new AramexShipping();
                    break;
                default:
                    throw new ArgumentException("no provider");
            }
            

        } 
    }
}
