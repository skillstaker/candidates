﻿using OrderProblem.Models;

namespace OrderProblem.shipping
{
    public interface IShipping
    {
        Task ShipAsync(order order);
    }
}
