﻿using OrderProblem.Models;
using OrderProblem.Payment;
using OrderProblem.Repository;
using OrderProblem.shipping;

namespace OrderProblem.Service
{
    public class OrderProcess
    {
        private readonly IRepository<order> _repo;

        public OrderProcess(IRepository<order> repo)
        {
            _repo = repo;
        }

        public async Task ProcessOrder(order order, string shipping)
        {
            IPaymentStrategy paymentStrategy;
            switch (order.paymentType)
            {
                case 1:
                    paymentStrategy = new Payment.CreidtCardPayment;
                    break;
                case 2:
                    paymentStrategy = new Payment.anotherPayment;
                    break;

            }
            if(paymentStrategy == null) 
            order.status = OrderStatus.payed;
            
            await _repo.AddAsync(order);
            var shipp = ShippingFactory.Create(
                shipping);
            order.status=OrderStatus.shipped;
            await _repo.UpdateAsync(order);
        }
    }
