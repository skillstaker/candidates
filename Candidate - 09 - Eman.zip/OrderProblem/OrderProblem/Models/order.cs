﻿using System.Security.Cryptography.X509Certificates;

namespace OrderProblem.Models
{

    public enum OrderStatus { pending, payed, shipped }
    public class order
    {

        public OrderStatus status { get; set; }
        public int id { get; set; }
        public string CustomerID { get; set; }
        public decimal Price { get; set; }
        public int paymentType {  get; set; } 

    }

}
