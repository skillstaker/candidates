﻿namespace OrderProcessingService.Applications
{
    public class Class1
    {

    }
}