﻿using OrderProcessingService.Applications.ShippingProvider;

namespace OrderProcessingService.Applications;

public static class ShippingFactory
{
    public static IShippingProvider Create(string provider)
       => provider switch
       {
           "FedEx" => new FedExShipping(),
           "DHL" => new DHLShipping(),
           _ => throw new NotImplementedException($"Unknown provider: {provider}")
       };
}
