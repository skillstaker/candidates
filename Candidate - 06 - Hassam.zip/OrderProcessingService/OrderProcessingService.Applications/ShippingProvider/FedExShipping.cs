﻿using OrderProcessingService.Domain.Models;

namespace OrderProcessingService.Applications.ShippingProvider
{
    public class FedExShipping : IShippingProvider
    {
        public void Ship(Order order)
        {
            Console.WriteLine("Order Shipped by DHL");
        }
    }
}
