﻿using OrderProcessingService.Domain.Models;

namespace OrderProcessingService.Applications.ShippingProvider;

public class DHLShipping : IShippingProvider
{
    public void Ship(Order order)
    {
        Console.WriteLine("Order Shipped by DHL");
    }
}
