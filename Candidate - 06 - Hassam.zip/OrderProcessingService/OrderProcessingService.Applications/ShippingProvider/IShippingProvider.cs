﻿using OrderProcessingService.Domain.Models;

namespace OrderProcessingService.Applications.ShippingProvider;

public interface IShippingProvider
{
    void Ship(Order order);
}
