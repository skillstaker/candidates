﻿using OrderProcessingService.Domain.Models;
using OrderProcessingService.Infrastructure.Helpers;

namespace OrderProcessingService.Applications.Services;

public interface IOrderService
{
    void ProcessOrder(Order order, IPaymentStrategy payment);
}
