﻿using OrderProcessingService.Infrastructure.Helpers;
using OrderProcessingService.Domain.Models;

namespace OrderProcessingService.Applications.Services;

public class OrderService : IOrderService
{
    private readonly IRepository<Order> _orderRepo;

    public OrderService(IRepository<Order> orderRepo)
    {
        _orderRepo = orderRepo;
    }

    public void ProcessOrder(Order order,IPaymentStrategy paymentStrategy)
    {
        throw NotImplementedException();
    }

    private Exception NotImplementedException()
    {
        throw new NotImplementedException();
    }
}
