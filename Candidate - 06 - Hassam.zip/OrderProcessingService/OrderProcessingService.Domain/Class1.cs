﻿namespace OrderProcessingService.Domain
{
    public class Class1
    {

    }
}