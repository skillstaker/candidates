﻿using OrderProcessingService.Domain.Models;

namespace OrderProcessingService.Infrastructure.Helpers;

public interface IPaymentStrategy
{
    void Pay(Order order);
}
