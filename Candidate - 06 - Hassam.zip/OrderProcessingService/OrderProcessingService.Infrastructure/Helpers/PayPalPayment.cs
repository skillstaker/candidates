﻿using OrderProcessingService.Domain.Models;

namespace OrderProcessingService.Infrastructure.Helpers
{
    public class PayPalPayment : IPaymentStrategy
    {
        public void Pay(Order order)
        {
            Console.WriteLine($"Paid {order.Amount} using PayPal");
        }
    }
}
