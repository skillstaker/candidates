﻿namespace OrderProcessingService.Infrastructure.Helpers
{
    public class InMemeroyRepository<T>: IRepository<T>
    {
        private readonly List<T> _items = new();
        
        public void Add(T entity)
        {
            _items.Add(entity);
        }

        public IEnumerable<T> GetAll()
        {
            return _items;
        }
    }
}
