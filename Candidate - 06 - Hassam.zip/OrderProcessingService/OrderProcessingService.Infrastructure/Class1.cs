﻿namespace OrderProcessingService.Infrastructure
{
    public class Class1
    {

    }
}