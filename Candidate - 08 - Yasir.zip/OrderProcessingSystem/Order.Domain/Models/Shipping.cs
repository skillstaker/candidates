﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Order.Domain.Models
{
    public class Shipping
    {
        public Shipping(string shippingId, string shippingName, string shippingAddress, string shippingCity)
        {
            this.ShippingId = Guid.NewGuid();
            this.ShippingName = shippingName;
            this.ShippingAddress = shippingAddress;
            this.ShippingCity = shippingCity;
        }

        public Guid ShippingId { get; set; }
        public string ShippingName { get; set; }
        public string ShippingAddress { get; set; }
        public string ShippingCity { get; set; }
    }
}