﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Order.Domain.Models
{
    public class ShippmentPayment
    {
        public ShippmentPayment() { }

        public Guid Id { get; set; }

        public Shipping Shippment { get; set; }

        public Payment Payment { get; set; }
    }
}
