﻿using Order.Domain.ValueTypes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autofac;

namespace Order.Domain.PaymentProcessing
{
    public class PaymentStrategyFactory
    {
        private readonly IServiceProvider serviceProvider;
        public PaymentStrategyFactory(IServiceProvider serviceProvider)
        {
            this.serviceProvider = serviceProvider;
        }

        public IPaymentStrategy GetPaymentStrategy(PaymentTypes paymentTypes)
        {
            return paymentTypes.ToString().ToLower() switch
            {
                "paypalpayment" => this.serviceProvider.GetRequiredService<PapalPayment>(),
                "cardpayment" => this.serviceProvider.GetRequiredService<CardPayment>(),
                "sripepayment" => this.serviceProvider.GetRequiredService<SripePayment>(),
                _ => throw new InvalidOperationException(),
            };
        }
    }
}
