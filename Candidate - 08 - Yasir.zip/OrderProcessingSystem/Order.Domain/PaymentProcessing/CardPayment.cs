﻿using Order.Domain.Models;
using Order.Domain.ValueTypes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Order.Domain.PaymentProcessing
{
    public class CardPayment : IPaymentStrategy
    {
        public Task<PaymentStatuses> Pay(Payment payment)
        {
            throw new NotImplementedException();
        }
    }
}
