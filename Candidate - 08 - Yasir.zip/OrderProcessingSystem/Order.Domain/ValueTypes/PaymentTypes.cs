﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Order.Domain.ValueTypes
{
    // Defining all types
    public enum PaymentTypes
    {
        CardPayment,
        StipePayment,
        PaypalPayment,
        CashPayment,
        BankTransfer
    }
}
