﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Order.Domain.ValueTypes
{
    // Define all possible payment stutes here
    public enum PaymentStatuses
    {
        Approved,
        Pending,
        Processed,
        Rejected
    }
}
