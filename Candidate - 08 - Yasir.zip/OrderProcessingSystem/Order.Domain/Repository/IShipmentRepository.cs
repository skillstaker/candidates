﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Order.Domain.Repository
{
    public interface IShipmentRepository<T> : IRepository<T> where T : class
    {
        // using this interface if need to extend our methods 
        // If we need add more methods we can list here below
    }
}
