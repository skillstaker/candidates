﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Order.Domain.Repository
{
    public interface IRepository<T> where T : class
    {
        Task<T> CreateAsync(T entity);

        Task DeleteAsync();

        Task<IEnumerable<T>> GetAllAsync();

        Task<bool> DeleteAsny(Guid guid);

        Task<T> GetByIdAsync(Guid id);
    }
}
