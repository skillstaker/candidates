﻿using Order.Domain.Models;
using Order.Domain.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Order.Infrastructure.Persistence
{
    public class PaymentRepository : IPaymentRepository<Payment>
    {
        public Task<Payment> CreateAsync(Payment entity)
        {
            throw new NotImplementedException();
        }

        public Task<bool> DeleteAsny(Guid guid)
        {
            throw new NotImplementedException();
        }

        public Task DeleteAsync()
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<Payment>> GetAllAsync()
        {
            throw new NotImplementedException();
        }

        public Task<Payment> GetByIdAsync(Guid id)
        {
            throw new NotImplementedException();
        }
    }
}
