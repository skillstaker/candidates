﻿using Order.Domain.Models;
using Order.Domain.Repository;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Order.Infrastructure.Persistence
{
    public class ShipmentRepository : IShipmentRepository<Shipping>
    {
        // Considering this as in-memory repo
        private readonly ConcurrentDictionary<Guid, Shipping> _repo = new(); 
        public Task<Shipping> CreateAsync(Shipping entity)
        {
            if (entity == null) throw new ArgumentNullException(nameof(entity));

            _repo[entity.ShippingId] = entity;
            return Task.FromResult(entity);
        }

        public Task<bool> DeleteAsny(Guid guid)
        {
            // Apply the same logic here below for all methods

            throw new NotImplementedException();
        }

        public Task DeleteAsync()
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<Shipping>> GetAllAsync()
        {
            throw new NotImplementedException();
        }

        public Task<Shipping> GetByIdAsync(Guid id)
        {
            throw new NotImplementedException();
        }
    }
}
