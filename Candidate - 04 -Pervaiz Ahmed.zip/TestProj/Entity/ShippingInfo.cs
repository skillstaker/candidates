﻿namespace TestProj.Entity
{
    public class ShippingInfo
    {
        public int Id { get; set; }
        public string Address { get; set; }
        public decimal cost { get; set; }

        public string Provider { get; set; }
    }
}
