﻿

namespace TestProj.Entity
{
    public class OrderLine
    {
        public int Id { get; set; }
        public int Quantity { get; set; }
        public decimal Cost { get; set; }
    }
}
