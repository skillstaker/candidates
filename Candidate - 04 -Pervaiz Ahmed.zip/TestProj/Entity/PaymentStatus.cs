﻿
namespace TestProj.Entity
{
    public class PaymentStatus
    {
        public int Id { get; set; }
        public string Status { get; set; }
        public string Message { get; set; }

    }
}
