﻿
namespace TestProj.Repository.Implementations
{
    using TestProj.Entity;
    using TestProj.Repository.Interfaces;

    public class ShippingRepository: GenericRepository<ShippingInfo>
    {
        private readonly IServiceProvider serviceProvider;
        public ShippingRepository(IServiceProvider serviceProvider)
        {
            this.serviceProvider = serviceProvider;
        }


    }
}
