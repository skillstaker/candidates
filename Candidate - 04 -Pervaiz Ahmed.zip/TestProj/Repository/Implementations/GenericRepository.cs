﻿
using TestProj.Repository.Interfaces;

namespace TestProj.Repository.Implementations
{
    public class GenericRepository<T> : IRepository<T> where T : class
    {
        private readonly List<T> _store = new List<T>();
        public Task AddAsync(T entity)
        {
            this._store.Add(entity);
            return Task.CompletedTask;
        }

        //public Task<bool> DeleteAsync(T entity)
        //{
        //    return Task.CompletedTask;
        //}

        public Task<T> GetAsync(Func<T, bool> predicate)
        {
            return Task.FromResult(this._store.FirstOrDefault(predicate));
        }

        public Task<IEnumerable<T>> ListAsync(Func<T, bool>? predicate =null)
        {
            var result = predicate == null ? this._store.AsEnumerable() : this._store.Where(predicate);
            return Task.FromResult(result);
        }
    }
}
