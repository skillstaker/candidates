﻿
using TestProj.Entity;
using TestProj.Repository.Interfaces;

namespace TestProj.Repository.Implementations
{
    public class OrderRepository : GenericRepository<Order>, IOrderRepository
    {
        public OrderRepository() { }

        public Task AddAsync(Order entity)
        {
            throw new NotImplementedException();
        }

        public Task<Order> GetAsync(Func<Order, bool> predicate)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<Order>> ListAsync(Func<Order, bool>? predicate = null)
        {
            throw new NotImplementedException();
        }

        public Task<bool> ProcessOrderAsync(Order order)
        {
            return Task.FromResult(true);
        }
    }
}
