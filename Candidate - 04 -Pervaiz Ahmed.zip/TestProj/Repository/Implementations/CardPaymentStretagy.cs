﻿
using TestProj.Entity;
using TestProj.Repository.Interfaces;

namespace TestProj.Repository.Implementations
{
    public class CardPaymentStretagy : IPaymentStrategy
    {
        public Task<PaymentStatus> ProcessPaymentAsync(Order order, decimal amount)
        {
            throw new NotImplementedException();
        }
    }
}
