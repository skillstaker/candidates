﻿

namespace TestProj.Repository.Interfaces
{
    using TestProj.Entity;
    public interface IOrderRepository: IRepository<Order>
    {
        public Task<bool> ProcessOrderAsync(Order order);
    }
}
