﻿namespace TestProj.Repository.Interfaces
{
    public interface IRepository<T>
    {
        public Task AddAsync(T entity);
        //Task DeleteAsync(T entity);
        public Task<T> GetAsync(Func<T, bool> predicate);
        public Task<IEnumerable<T>> ListAsync(Func<T, bool>? predicate= null);
    }
}
