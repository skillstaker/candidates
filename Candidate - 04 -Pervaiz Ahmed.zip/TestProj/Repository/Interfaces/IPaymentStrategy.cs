﻿namespace TestProj.Repository.Interfaces
{
    using TestProj.Entity;
    public interface IPaymentStrategy
    {
        Task<PaymentStatus> ProcessPaymentAsync(Order order, decimal amount);
    }
}
