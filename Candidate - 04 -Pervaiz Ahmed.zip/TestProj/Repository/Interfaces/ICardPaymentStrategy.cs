﻿namespace TestProj.Repository.Interfaces
{
    public interface ICardPaymentStrategy
    {

    }
}
