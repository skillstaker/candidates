﻿

namespace TestProj.Repository.Interfaces
{
    public interface IShippingRepository: IRepository<IShippingRepository>
    {
    }
}
